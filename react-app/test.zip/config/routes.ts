﻿export default [
  { path: '/', redirect: '/welcome' },
  { path: '/login', layout: false, component: './Login' },
  {
    path: '/welcome',
    name: 'welcome',
    icon: 'smile',
    component: './Welcome',
  },
  {
    name: 'list.table-list',
    key: '/list',
    icon: 'table',
    path: '/list',
    component: './TableList',
  },
  {
    name: 'edit',
    key: '/edit',
    icon: 'table',
    // path: '/edit',
    path: 'http://www.baidu.com',
    component: './Edit',
  },

  // {
  //   path: '/admin',
  //   name: 'admin',
  //   icon: 'crown',
  //   access: 'canAdmin',
  //   routes: [
  //     {
  //       path: '/admin/sub-page',
  //       name: 'sub-page',
  //       icon: 'smile',
  //       component: './Welcome',
  //     },
  //     {
  //       component: './404',
  //     },
  //   ],
  // },

  { path: '/404', layout: false, component: './404' },
  { path: '*', redirect: '/404' },
];
