import React from 'react'

const Footer: React.FC = () => {
  return null
};

export default Footer;
