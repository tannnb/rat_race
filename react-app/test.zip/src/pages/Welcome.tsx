import React, { useState, useEffect } from 'react';
import { Form, Table, Input, Checkbox, Select, Button } from 'antd';
import { ConsoleSqlOutlined, LikeTwoTone, MenuOutlined } from '@ant-design/icons';
import { arrayMoveImmutable } from 'array-move';
import type { SortableContainerProps, SortEnd } from 'react-sortable-hoc';
import { SortableContainer, SortableElement, SortableHandle } from 'react-sortable-hoc';
import _ from 'lodash';
import './we.css';

const { Option } = Select;
const DragHandle = SortableHandle(() => <MenuOutlined style={{ cursor: 'grab', color: '#999' }} />);
const SortableItem = SortableElement((props: React.HTMLAttributes<HTMLTableRowElement>) => (
  <tr {...props} />
));
const SortableBody = SortableContainer((props: React.HTMLAttributes<HTMLTableSectionElement>) => (
  <tbody {...props} />
));

const dateTypeMap = {
  text: '文本',
  date: '日期',
  int: '数值',
  文本: 'text',
  日期: 'date',
  数值: 'int',
};
const Welcome: React.FC = () => {
  const [form] = Form.useForm();
  const [edit, setEdit] = useState(false);
  const [dataSource, setDataSource] = useState([
    {
      key: 0,
      index: 0,
      name: '测试名称1',
      dataType: 'text',
      where: false,
    },
    {
      key: 1,
      index: 1,
      name: '测试名称2',
      dataType: 'date',
      where: true,
    },
  ]);

  useEffect(() => {
    setDataSource(dataSource);
    form.setFieldsValue({ table: dataSource });
  }, []);

  const columns = [
    {
      title: '',
      dataIndex: 'sort',
      width: 30,
      className: 'drag-visible',
      render: () => <DragHandle />,
    },
    {
      title: '序号',
      width: 80,
      render: (sort: number, record: any) => {
        return (
          <Form.Item style={{ margin: 0 }} shouldUpdate>
            {() => {
              return (
                <Form.Item noStyle style={{ margin: 0 }}>
                  <div>{record.index + 1}</div>
                </Form.Item>
              );
            }}
          </Form.Item>
        );
      },
    },
    {
      title: '中文字段',
      dataIndex: 'name',
      render: (_, record: any, recordIndex: number) => {
        return (
          <Form.Item style={{ margin: 0 }} shouldUpdate>
            {() => {
              return (
                <Form.Item
                  noStyle
                  style={{ margin: 0 }}
                  name={[recordIndex, 'name']}
                  rules={[{ required: true, message: '必填' }]}
                >
                  {edit ? <Input key={recordIndex} /> : <div>{record?.name || '-'}</div>}
                </Form.Item>
              );
            }}
          </Form.Item>
        );
      },
    },
    {
      title: '类型',
      dataIndex: 'dataType',
      render: (_, record: any, recordIndex: number) => {
        return (
          <Form.Item style={{ margin: 0 }} shouldUpdate>
            {() => {
              return (
                <Form.Item noStyle style={{ margin: 0 }} name={[recordIndex, 'dataType']}>
                  {edit ? (
                    <Select>
                      <Option value="text">文本</Option>
                      <Option value="date">日期</Option>
                      <Option value="int">数值</Option>
                    </Select>
                  ) : (
                    <div>{dateTypeMap[record.dataType] || '-'}</div>
                  )}
                </Form.Item>
              );
            }}
          </Form.Item>
        );
      },
    },
    {
      title: '是否索引',
      dataIndex: 'where',
      render: (_, record: any, recordIndex: number) => {
        return (
          <Form.Item style={{ margin: 0 }} shouldUpdate fieldKey={[record.fieldKey, 'where']}>
            {() => {
              return (
                <Form.Item noStyle style={{ margin: 0 }} name={[recordIndex, 'where']}>
                  {edit ? (
                    <Checkbox
                      checked={record.where}
                      key={recordIndex}
                      onChange={(e) => {
                        const result = dataSource?.map((data) => {
                          if (data.index === record.index) {
                            data.where = e.target.checked;
                          }
                          return data;
                        });
                        setDataSource(result);
                        form.setFieldsValue({ table: result });
                      }}
                    />
                  ) : (
                    <div>{record?.where ? '是' : '否'}</div>
                  )}
                </Form.Item>
              );
            }}
          </Form.Item>
        );
      },
    },
    {
      title: '操作',
      render: (_, record: any) => {
        return (
          <Button
            onClick={() => {
              console.log(record);
              const result = dataSource?.filter((data) => data.index !== record.index);
              setDataSource(result);
              form.setFieldsValue({ table: result });
            }}
          >
            删除
          </Button>
        );
      },
    },
  ];

  const onSortEnd = ({ oldIndex, newIndex }: SortEnd) => {
    if (oldIndex !== newIndex) {
      const table = form.getFieldsValue().table;
      const newData = arrayMoveImmutable(table, oldIndex, newIndex).filter((el) => !!el);

      setDataSource(newData);
      form.setFieldsValue({ table: newData });
      form.validateFields();
    }
  };

  const DraggableContainer = (props: SortableContainerProps) => (
    <SortableBody
      useDragHandle
      disableAutoscroll
      helperClass="row-dragging"
      onSortEnd={onSortEnd}
      {...props}
    />
  );

  const DraggableBodyRow: React.FC<any> = ({ className, style, ...restProps }) => {
    const index = dataSource?.findIndex((x) => x.index === restProps['data-row-key']);
    return <SortableItem index={index} {...restProps} />;
  };

  const getMaxIndex = (table: any) => {
    let currentIndex = 0;
    table?.forEach((item: any) => {
      if (item.index >= currentIndex) {
        currentIndex = item.index;
      }
    });
    return currentIndex + 1;
  };

  const expandState = () => {
    const newData = form.getFieldsValue().table;

    setDataSource(newData);
    form.setFieldsValue({ table: newData });
    setEdit(!edit);
  };

  const increateAdd = () => {
    const table = form.getFieldsValue().table;
    const index = getMaxIndex(table);

    const params = {
      key: index,
      index: index,
      name: '',
      dataType: '',
      where: false,
    };
    table.push(params);

    setDataSource(table);
    form.setFieldsValue({ table });
  };

  return (
    <div>
      <div>hhahha </div>
      <Button onClick={() => expandState()}>切换状态</Button>
      <Button onClick={() => increateAdd()}>增加一条</Button>

      <Form form={form}>
        <Form.List name="table">
          {() => {
            return (
              <Table
                bordered
                rowKey="key"
                dataSource={dataSource}
                columns={columns}
                pagination={false}
                components={{
                  body: {
                    wrapper: DraggableContainer,
                    row: DraggableBodyRow,
                  },
                }}
              />
            );
          }}
        </Form.List>
      </Form>
    </div>
  );
};

export default Welcome;
