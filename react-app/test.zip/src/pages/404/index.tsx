import { Button, Result } from 'antd';
import { history } from 'umi';
import './index.css'
const NoFoundPage = () => {
  return (
    <>
      {/*<div style={{'--bgColor':'red'}} className='not'>123123</div>*/}
      <Result
        status="404"
        title="404"
        subTitle="Sorry, the page you visited does not exist."
        extra={
          <Button type="primary" onClick={() => history.push('/')}>
            回到首页
          </Button>
        }
      />
    </>

  )
}

export default NoFoundPage;

//
// <style>
//   @keyframes shake {
//   10%,
//   90% {
//   transform: translate3d(-1px, 0, 0);
// }
//
//   20%,
//   80% {
//   transform: translate3d(2px, 0, 0);
// }
//
//   30%,
//   50%,
//   70% {
//   transform: translate3d(-4px, 0, 0);
// }
//
//   40%,
//   60% {
//   transform: translate3d(4px, 0, 0);
// }
// }
//
//   .apply-shake {
//   animation: shake 0.82s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;
// }
// </style>
