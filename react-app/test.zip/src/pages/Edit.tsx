import React from 'react';
const Edit: React.FC = () => {
  return <>edit</>;
};

export default Edit;
