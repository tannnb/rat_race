import React from 'react';
import type { ReactNode, ReactElement } from 'react';
import type { Settings as LayoutSettings, MenuDataItem } from '@ant-design/pro-layout';
import { PageLoading, WaterMark } from '@ant-design/pro-layout';
import type { RunTimeLayoutConfig } from 'umi';
import { history, dynamic, Link } from 'umi';
import { ConfigProvider } from 'antd';
import RightContent from '@/components/RightContent';
import { SmileOutlined, HeartOutlined } from '@ant-design/icons';
import { currentUser as queryCurrentUser } from './services/ant-design-pro/api';
import defaultSettings from '../config/defaultSettings';

const loginPath = '/login';

/** 获取用户信息比较慢的时候会展示一个 loading */
export const initialStateConfig = {
  loading: <PageLoading />,
};

// eslint-disable-next-line @typescript-eslint/no-shadow
export async function render(oldRender: () => void) {
  console.log('render');
  oldRender();
}

export async function patchRoutes({ routes }: { routes: Record<string, any>[] }) {
  // routes[1].routes.splice(routes[1].routes.length - 2, 0, {
  //   name: 'edit',
  //   key: '/edit',
  //   icon: 'table',
  //   path: '/edit',
  //   component: dynamic({
  //     loader: () => import('./pages/Edit'),
  //   }),
  // });
  // console.log('routes', routes);
  return routes;
}

const RootContainer = (props: { children: ReactElement; routes: Record<string, any>[] }) => {
  return (
    <WaterMark content={'蚂蚁集团'}>
      <ConfigProvider>
        {React.cloneElement(props.children, {
          routes: props.routes,
        })}
      </ConfigProvider>
    </WaterMark>
  );
};
export function rootContainer(container: ReactNode) {
  console.log('rootContainer', container);
  return React.createElement(RootContainer, null, container);
}

//  https://umijs.org/zh-CN/plugins/plugin-initial-state
export async function getInitialState(): Promise<{
  settings?: Partial<LayoutSettings>;
  currentUser?: API.CurrentUser;
  loading?: boolean;
  menu: MenuDataItem[];
  fetchUserInfo?: () => Promise<API.CurrentUser | undefined>;
}> {
  console.log('getInitialState');
  const fetchUserInfo = async () => {
    try {
      const msg = await queryCurrentUser();
      return msg.data;
    } catch (error) {
      history.push(loginPath);
    }
    return undefined;
  };
  // 如果不是登录页面，执行
  if (history.location.pathname !== loginPath) {
    const currentUser = await fetchUserInfo();
    const menuData = [
      {
        path: '/welcome',
        name: 'welcome',
        icon: 'smile',
        component: './Welcome',
      },
      {
        name: '编辑',
        key: '/edit',
        icon: 'table',
        path: 'http://www.baidu.com',
      },
    ];
    return {
      fetchUserInfo,
      currentUser,
      settings: defaultSettings,
      menu: menuData,
    };
  }
  return {
    fetchUserInfo,
    settings: defaultSettings,
    menu: [],
  };
}

const iconEnum = {
  table: <SmileOutlined />,
};
const loopMenuItem = (menus: MenuDataItem[]): MenuDataItem[] =>
  menus.map(({ icon, children, ...item }) => {
    console.log(icon);
    return {
      ...item,
      //  icon: icon && IconMap[icon as string],
      // 方案一： 此用法会把所有的图标库引入，造成增加工程3M大小，请谨用
      // icon: icon && React.createElement(Icon[icon]),
      // 方案二： 建议用此方案，只引入用到的图标，避免图标库全部引入
      icon: icon && iconEnum[icon],
      children: children && loopMenuItem(children),
    };
  });

// ProLayout 支持的api https://procomponents.ant.design/components/layout
export const layout: RunTimeLayoutConfig = ({ initialState, setInitialState }) => {
  console.log('layout', initialState);
  // menu: MenuDataItem[]
  return {
    menuDataRender: () => {
      return loopMenuItem(initialState?.menu);
    },
    // menuItemRender: (menuItemProps, defaultDom) => {

    //   console.log('menuItemProps', menuItemProps)
    //   if (!menuItemProps.path) {
    //     return defaultDom;
    //   }
    //   // 支持二级菜单显示icon
    //   return (
    //     <Link to={menuItemProps.path}>
    //       {menuItemProps.pro_layout_parentKeys &&
    //         menuItemProps.pro_layout_parentKeys.length > 0 &&
    //         menuItemProps.icon}
    //       {defaultDom}
    //     </Link>
    //   );
    // },

    rightContentRender: () => <RightContent />,
    disableContentMargin: false,
    waterMarkProps: {
      // content: initialState?.currentUser?.name,
    },
    footerRender: false,
    onPageChange: () => {
      console.log('进入了页面');
      // patchRoutes()
      const { location } = history;
      // 如果没有登录，重定向到 login
      if (!initialState?.currentUser && location.pathname !== loginPath) {
        history.push(loginPath);
      }
    },
    menuHeaderRender: undefined,
    // 自定义 403 页面
    // unAccessible: <div>unAccessible</div>,
    // 增加一个 loading 的状态
    childrenRender: (children, props) => {
      // if (initialState?.loading) return <PageLoading />;
      return <>{children}</>;
    },
    menu: {},
    ...initialState?.settings,
  };
};
