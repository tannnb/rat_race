// @ts-nocheck

  import SmileOutlined from '@ant-design/icons/es/icons/SmileOutlined';
import TableOutlined from '@ant-design/icons/es/icons/TableOutlined'
  export default {
    SmileOutlined,
TableOutlined
  }