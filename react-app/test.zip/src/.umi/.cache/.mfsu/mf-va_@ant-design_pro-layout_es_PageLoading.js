import _ from '@ant-design/pro-layout/es/PageLoading';
export default _;
