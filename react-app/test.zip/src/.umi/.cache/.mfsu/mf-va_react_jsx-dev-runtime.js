import _ from '/Users/tanbing/project/ReactProject/react-admin/node_modules/react/jsx-dev-runtime';
export default _;
export * from '/Users/tanbing/project/ReactProject/react-admin/node_modules/react/jsx-dev-runtime';
