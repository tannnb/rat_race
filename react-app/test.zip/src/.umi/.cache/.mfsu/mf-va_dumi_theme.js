export * from '/Users/tanbing/project/ReactProject/react-admin/node_modules/@umijs/preset-dumi/lib/theme';
