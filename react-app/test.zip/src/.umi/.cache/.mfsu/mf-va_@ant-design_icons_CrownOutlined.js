import _ from '@ant-design/icons/CrownOutlined';
export default _;
