import _ from 'moment/locale/zh-cn';
export default _;
export * from 'moment/locale/zh-cn';
