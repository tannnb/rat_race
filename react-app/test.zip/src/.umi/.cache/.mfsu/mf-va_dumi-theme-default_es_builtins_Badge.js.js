import _ from '/Users/tanbing/project/ReactProject/react-admin/node_modules/dumi-theme-default/es/builtins/Badge.js';
export default _;
