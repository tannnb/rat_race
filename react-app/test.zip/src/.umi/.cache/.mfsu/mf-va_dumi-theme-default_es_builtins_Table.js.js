import _ from '/Users/tanbing/project/ReactProject/react-admin/node_modules/dumi-theme-default/es/builtins/Table.js';
export default _;
