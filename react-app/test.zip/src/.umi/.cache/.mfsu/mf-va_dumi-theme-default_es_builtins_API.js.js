import _ from '/Users/tanbing/project/ReactProject/react-admin/node_modules/dumi-theme-default/es/builtins/API.js';
export default _;
