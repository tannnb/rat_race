(self["webpackChunkant_design_pro"] = self["webpackChunkant_design_pro"] || []).push([["mf-dep_src_umi_cache_mfsu_mf-va_array-move_js"],{

/***/ "./node_modules/array-move/index.js":
/*!******************************************!*\
  !*** ./node_modules/array-move/index.js ***!
  \******************************************/
/***/ (function(__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "arrayMoveMutable": function() { return /* binding */ arrayMoveMutable; },
/* harmony export */   "arrayMoveImmutable": function() { return /* binding */ arrayMoveImmutable; }
/* harmony export */ });
function arrayMoveMutable(array, fromIndex, toIndex) {
	const startIndex = fromIndex < 0 ? array.length + fromIndex : fromIndex;

	if (startIndex >= 0 && startIndex < array.length) {
		const endIndex = toIndex < 0 ? array.length + toIndex : toIndex;

		const [item] = array.splice(fromIndex, 1);
		array.splice(endIndex, 0, item);
	}
}

function arrayMoveImmutable(array, fromIndex, toIndex) {
	array = [...array];
	arrayMoveMutable(array, fromIndex, toIndex);
	return array;
}


/***/ }),

/***/ "./src/.umi/.cache/.mfsu/mf-va_array-move.js":
/*!***************************************************!*\
  !*** ./src/.umi/.cache/.mfsu/mf-va_array-move.js ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "arrayMoveImmutable": function() { return /* reexport safe */ array_move__WEBPACK_IMPORTED_MODULE_0__.arrayMoveImmutable; },
/* harmony export */   "arrayMoveMutable": function() { return /* reexport safe */ array_move__WEBPACK_IMPORTED_MODULE_0__.arrayMoveMutable; }
/* harmony export */ });
/* harmony import */ var array_move__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! array-move */ "./node_modules/array-move/index.js");



/***/ })

}]);