import _ from '/Users/tanbing/project/ReactProject/react-admin/node_modules/dumi-theme-default/es/builtins/Example.js';
export default _;
