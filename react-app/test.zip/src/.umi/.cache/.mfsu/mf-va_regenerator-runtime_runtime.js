import _ from '/Users/tanbing/project/ReactProject/react-admin/node_modules/umi/node_modules/regenerator-runtime/runtime.js';
export default _;
export * from '/Users/tanbing/project/ReactProject/react-admin/node_modules/umi/node_modules/regenerator-runtime/runtime.js';
