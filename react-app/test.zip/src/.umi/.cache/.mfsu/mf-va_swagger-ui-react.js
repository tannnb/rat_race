import _ from 'swagger-ui-react';
export default _;
