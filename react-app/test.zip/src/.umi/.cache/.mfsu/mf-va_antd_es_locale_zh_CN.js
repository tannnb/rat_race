import _ from '/Users/tanbing/project/ReactProject/react-admin/node_modules/antd/es/locale/zh_CN';
export default _;
