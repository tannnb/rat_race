export * from '/Users/tanbing/project/ReactProject/react-admin/node_modules/@umijs/plugin-request/lib/ui/index.js';
