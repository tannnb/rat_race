import _ from '/Users/tanbing/project/ReactProject/react-admin/node_modules/antd/es/notification';
export default _;
export * from '/Users/tanbing/project/ReactProject/react-admin/node_modules/antd/es/notification';
