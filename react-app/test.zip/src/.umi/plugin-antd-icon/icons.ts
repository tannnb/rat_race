// @ts-nocheck

import SmileOutlined from '@ant-design/icons/SmileOutlined';
import TableOutlined from '@ant-design/icons/TableOutlined'

export default {
  SmileOutlined,
TableOutlined
}
    