// @ts-nocheck
import { Plugin } from '/Users/tanbing/project/ReactProject/react-admin/node_modules/umi/node_modules/@umijs/runtime';

const plugin = new Plugin({
  validKeys: ['modifyClientRenderOpts','patchRoutes','rootContainer','render','onRouteChange','__mfsu','getInitialState','initialStateConfig','locale','layout','layoutActionRef','request',],
});

export { plugin };
