import type { IRouteComponentProps } from 'umi';

export default function Layout({
  children,
  location,
  route,
  history,
  match,
}: IRouteComponentProps) {
  return (
    <>
      <div>123123111111112312311111111231231111111</div>
      {children}
    </>
  );
}
