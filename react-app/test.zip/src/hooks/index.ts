import { useReducer } from 'react';
import type { Dispatch } from 'react';

export const useStates = <T>(initStates: T): [T, Dispatch<Partial<T>>] => {
  const [states, dispatch] = useReducer(
    (state: T, nextStates: Partial<T>) => ({ ...state, ...nextStates }),
    initStates,
  );
  return [states, dispatch];
};
